﻿using UnityEngine;
using System.Collections;

public class GUIEvents : MonoBehaviour {

    void OnMouseDown()
    {
        Debug.Log(transform.name);
    }

	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
	
	}
}
