// This file was @generated with LibOVRPlatform/codegen/main. Do not modify it!

namespace Oculus.Platform
{

  using Description = System.ComponentModel.DescriptionAttribute;

  public enum CloudStorageUpdateStatus : int
  {
    [Description("UNKNOWN")]
    Unknown,

    [Description("OK")]
    Ok,

    [Description("BETTER_VERSION_STORED")]
    BetterVersionStored,

    [Description("MANUAL_MERGE_REQUIRED")]
    ManualMergeRequired,

  }

}
